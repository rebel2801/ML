import pandas as pd
df = pd.read_csv(r"C:\Users\Hitesh\OneDrive\Desktop\SNU\Sem 6\ML Lab\Ex5\Telco-Customer-Churn.csv")
df=df.drop(['customerID'],axis=1)
#%%finding columns with nan values
col=[]
for i in df:
    col.append(i)
for i in col:
    print(df[i].unique())
#no nan values


#%%binary strings change to 1 and 0

val=['Partner','Dependents','PhoneService','PaperlessBilling','Churn',
     ]
for i in val:
    df[i]=df[i].map({'Yes':1,'No':0})

df['gender']=df['gender'].map({'Female':1,'Male':0})
#%%remove empty spaces and change to numeric
index=[]
for i in range(0,7043):
    if df['TotalCharges'][i].isspace():
        index.append(i)
df=df.drop(index,axis=0)
df['TotalCharges'] = pd.to_numeric(df['TotalCharges'])
#%%seperate x and y
y=df.iloc[:,-1]
x=df.iloc[:,:-1]
#%% getdummies

strings=['MultipleLines','InternetService','OnlineSecurity','OnlineBackup'
         ,'DeviceProtection','TechSupport','StreamingTV','StreamingMovies',
         'Contract','PaymentMethod']

temp=pd.get_dummies(x['MultipleLines'],dtype='int')
x=x.join(temp)

temp=pd.get_dummies(x['InternetService'],dtype='int')
x=x.join(temp,how = 'left', rsuffix = 'InternetService')


temp=pd.get_dummies(x['OnlineSecurity'],dtype='int')
x=x.join(temp,how = 'left', lsuffix = 'MultipleLines', rsuffix = 'OnlineSecurity')

temp=pd.get_dummies(x['OnlineBackup'],dtype='int')
x=x.join(temp,how = 'left', rsuffix = 'OnlineBackup')

temp=pd.get_dummies(x['DeviceProtection'],dtype='int')
x=x.join(temp,how = 'left', rsuffix = 'DeviceProtection')

temp=pd.get_dummies(x['TechSupport'],dtype='int')
x=x.join(temp,how = 'left', rsuffix = 'TechSupport')

temp=pd.get_dummies(x['StreamingTV'],dtype='int')
x=x.join(temp,how = 'left', rsuffix = 'StreamingTV')

temp=pd.get_dummies(x['StreamingMovies'],dtype='int')
x=x.join(temp,how = 'left', rsuffix = 'StreamingMovies')

temp=pd.get_dummies(x['Contract'],dtype='int')
x=x.join(temp,how = 'left', rsuffix = 'Contract')

temp=pd.get_dummies(x['PaymentMethod'],dtype='int')
x=x.join(temp,how = 'left', rsuffix = 'PaymentMethod')

x=x.drop(strings,axis=1)
#%%metric

from sklearn import metrics

#%%split data
from sklearn.model_selection import train_test_split

x_train, x_test, y_train, y_test = train_test_split(x, y, test_size=0.25, random_state=16)
#%%log regression:
from sklearn.linear_model import LogisticRegression
logreg = LogisticRegression()
logreg.fit(x_train,y_train)
y_pred = logreg.predict(x_test)
from sklearn.metrics import classification_report
print(classification_report(y_test, y_pred))
accuracy = metrics.accuracy_score(y_test, y_pred)
print('Accuracy of Logistic Regression Classification is: ',accuracy)

#%%knn

from sklearn.neighbors import KNeighborsClassifier 
knn = KNeighborsClassifier(n_neighbors=20) 
knn.fit(x_train, y_train) 
y_pred=knn.predict(x_test)

print(classification_report(y_test, y_pred))
accuracy = metrics.accuracy_score(y_test, y_pred)
print(accuracy)
#%%naive gaussian
from sklearn.naive_bayes import GaussianNB
model = GaussianNB()
model.fit(x_train, y_train)
y_pred = model.predict(x_test)
print("Actual Value:", y_test)
print("Predicted Value:", y_pred)

print(classification_report(y_test, y_pred))
accuracy = metrics.accuracy_score(y_test, y_pred)
print('Accuracy of Naive Bayes Classification is: ',accuracy)

#%%decision tree

from sklearn.tree import DecisionTreeClassifier
dtree = DecisionTreeClassifier()
dtree = dtree.fit(x_train.values, y_train.values)
y_pred=dtree.predict(x_test)
print(classification_report(y_test, y_pred))
accuracy = metrics.accuracy_score(y_test, y_pred)
print('Accuracy of Decision Tree Classification is: ',accuracy)
#%%svm
from sklearn import svm

clf=svm.SVC()
clf.fit(x_train,y_train)
y_pred=clf.predict(x_test)
print(classification_report(y_test, y_pred))
accuracy = metrics.accuracy_score(y_test, y_pred)
print('Accuracy of SVM Classification is: ',accuracy)


