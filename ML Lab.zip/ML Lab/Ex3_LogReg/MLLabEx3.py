import pandas as pd
data=pd.read_csv(r"C:\Users\Suhash\Downloads\telecom_customer_churn.csv")
data=data.drop(['Customer ID','Gender','Married','Offer','Zip Code','Latitude','Longitude','City','Churn Category','Churn Reason'],axis=1)

drop=[
 'Avg Monthly Long Distance Charges',
 'Multiple Lines',
 'Avg Monthly GB Download',
 'Online Security',
 'Online Backup',
 'Device Protection Plan',
 'Premium Tech Support',
 'Streaming TV',
 'Streaming Movies',
 'Streaming Music',
 'Unlimited Data']

data=data.dropna(subset=drop)

y=data.iloc[:,-1]
df=data.iloc[:,:-1]

val=['Online Backup','Device Protection Plan','Premium Tech Support','Streaming TV',
     'Phone Service','Multiple Lines','Internet Service','Online Security','Streaming Movies','Streaming Music','Unlimited Data','Paperless Billing']
for i in val:
    df[i]=df[i].map({'Yes':1,'No':0})

Payment=pd.get_dummies(df['Payment Method'],dtype='int')
df=df.join(Payment)

Type=pd.get_dummies(df['Internet Type'],dtype='int')
df=df.join(Type)

Contract=pd.get_dummies(df['Contract'],dtype='int')
df=df.join(Contract)

df=df.drop(['Payment Method','Internet Type','Contract',],axis=1)






from sklearn.model_selection import train_test_split

x_train, x_test, y_train, y_test = train_test_split(df, y, test_size=0.25, random_state=16)

from sklearn import preprocessing
scaler = preprocessing.StandardScaler().fit(x_train)
x_scaled = scaler.transform(x_train)
from sklearn.linear_model import LogisticRegression
logreg = LogisticRegression()
logreg.fit(x_scaled,y_train)
y_pred = logreg.predict(x_test)
from sklearn.metrics import classification_report
print(classification_report(y_test, y_pred))




